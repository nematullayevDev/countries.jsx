
import Header from "./Header";

function Page() {

  return (
    <div className="pageContainer">
      <Header />

      <div className="pageMain">
        <button className="backBtn">{"<"} Back</button>
        <div className="pageCount">
          <img className="pageFlag" src="./flag.png" alt="" />
          <div className="pageWrap">
            <h2 className="pageCountName">Belgium</h2>
            <div className="pageULLI">
              <ul className="page1UL">
                <li className="population">
                  Native Name: <span className="wordSpan"> België</span>
                </li>
                <li className="population">
                  Population: <span className="wordSpan"> 11,319,511</span>
                </li>
                <li className="population">
                  Region: <span className="wordSpan"> Europe</span>
                </li>
                <li className="population">
                  Sub Region: <span className="wordSpan"> Western Europe</span>
                </li>
                <li className="population">
                  Capital: <span className="wordSpan"> Brussels</span>
                </li>
              </ul>

              <ul className="page2Ul">
                <li className="population">
                  Top Level Domain: <span className="wordSpan"> .be</span>
                </li>
                <li className="population">
                  Currencies: <span className="wordSpan"> Euro</span>
                </li>
                <li className="population">
                  Languages: <span className="wordSpan">Dutch</span>,
                  <span className="wordSpan">French</span>,
                  <span className="wordSpan">German</span>
                </li>
              </ul>
            </div>

            <div className="pageFooter">
              <h3 className="borderCountres">Border Countries: </h3>
              <button className="bordercountBtn">France</button>
              <button className="bordercountBtn">Germany</button>
              <button className="bordercountBtn">Netherlands</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Page;
