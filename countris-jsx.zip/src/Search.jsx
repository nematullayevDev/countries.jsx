function Search() {
  return (
    <div className="searDiv">
      <div className="searchinpDiv">
        <img className="searchImg" src="../search.svg" alt="" />
        <input className="search" type="text" placeholder="Search for a country…" />
      </div>
      <div className="selectdiv">
        <select name="" id="" className="select" >
          <option value="Africa" className="options">Africa</option>
          <option value="America" className="options">America</option>
          <option value="Asia" className="options">Asia</option>
          <option value="Europe" className="options">Europe</option>
          <option value="Oceania" className="options">Oceania</option>
        </select>
      </div>
    </div>
  );
}

export default Search;
