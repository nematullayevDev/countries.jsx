import { useState } from "react";
import Header from "./Header";
import Search from "./Search";
import { useEffect } from "react";
import Page from "./page";
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  RouterProvider,
  createBrowserRouter,
} from "react-router-dom";
const Url = "https://frontend-mentor-apis-6efy.onrender.com/countries";

function App() {
  const [posts, setPost] = useState([]);

  const getApiUrl = async () => {
    const res = await fetch(Url);
    const datas = await res.json();
    setPost(datas.data);
  };
  console.log(posts);

  useEffect(() => {
    getApiUrl();
  }, []);

  return (
    <div className="container">
      <Header />,
      <Search />
      <main className="main">
        <ul className="mainUl">
          {posts.map((post) => {
            {console.log(post)}
            <li className="mainLi" key={post.id}>
              <a to="/Page">
                <img className="imgFlag" src={post.flags.svg} alt="" />
              </a>

              <div className="abautCountr">
                <h2 className="countName">{post.name.common}</h2>
                <div className="wordCount">
                  <p className="population">
                    Population:
                    <span className="wordSpan"> {post.population}</span>
                  </p>
                  <p className="population">
                    Region: <span className="wordSpan">{post.region}</span>
                  </p>
                  <p className="population">
                    Capital: <span className="wordSpan">{post.capital}</span>
                  </p>
                </div>
              </div>
            </li>;
          })}
        </ul>
      </main>
    </div>
  );
}

export default App;
